

<div style="background-color: --bs-body-bg; margin: 20px; display:block;">
    <h2 class="card-title" style="text-align: center;">Do you want to sign in?</h2>
    <p style="text-align: center;">By Signing in you can save your suggested foods!!</p>
</div>